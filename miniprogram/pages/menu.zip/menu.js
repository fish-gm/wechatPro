// pages/menu/menu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 菜单内容部分
    navList: [
      // {
      //   title: '标题1',
      //   id: 'title1',
      //   content: [
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //   ]
      // },
      // {
      //   title: '标题2',
      //   id: 'title2',
      //   content: [
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //     { desc: '内容块1' },
      //     { desc: '内容块2' },
      //     { desc: '内容块3' },
      //   ]
      // }
    ],
    currentNavIndex: 0,
    naWidth: 0,
    contentHeight: '',
    toView: '',
  },

  onLoad(){

    // 获取菜单数据
    wx.cloud.callFunction({
      name:'get_menu_data'
    }).then(res => {
      console.log('res',res.result.data[0].result.menu);
      let menu=res.result.data[0].result.menu;
      this.setData({
        navList:[...menu]
      })

    }).catch(err=>{
      console.log('err',err);
    })
  },
  // 跳转到搜索页面
  toSearchPage(e) {
    const keyword = e.detail.value;
    console.log('keyword', keyword);
    wx.navigateTo({
      url: '/pages/searchResult/searchResult?keyword=' + keyword
    })
  },
  // 获取搜索结果
  onSearch(e) {
    const keyword = e.detail.value;
    console.log('keyword', keyword);
  },

  // 菜单部分
  // 点击侧边导航栏
  onClickNav(e) {
    const index = e.currentTarget.dataset.index;

    this.setData({
      currentNavIndex: index,
      // 滚动到相应的id区域
      toView: this.data.navList[index].id
    });
  },
  // 滚动内容区
  onContentScroll(e) {
    const scrollTop = e.detail.scrollTop;

    let oneItems=[];
    wx.createSelectorQuery().selectAll('.one-item').boundingClientRect(rects => {
      oneItems=[...rects];

      let startHeight=0;
      for(let i=0;i<oneItems.length;i++){
        if(i==0){
          startHeight=0;
        }else{
          startHeight += oneItems[i-1].height;
        }
        let endHeight = startHeight +  oneItems[i].height;

        if(scrollTop >= startHeight && scrollTop< endHeight){
          // console.log('i',i);
          this.setData({
            // 侧边导航栏高亮
            currentNavIndex:i
          })
        }
      }

    }).exec();

  },

})